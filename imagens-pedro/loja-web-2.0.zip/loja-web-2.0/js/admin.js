// js/admin.js

import { produtosIniciais } from './products.js';
import { renderizarProdutos } from './main.js';

let produtos = JSON.parse(localStorage.getItem('produtosLoja')) || [...produtosIniciais];
let produtoEditando = null;
let novoProduto = {};

const adminFormContainer = document.getElementById('admin-form-container');
const adminToggle = document.getElementById('admin-toggle');

export function toggleModoAdmin() {
  const isAdmin = localStorage.getItem('isAdmin') === 'true';
  localStorage.setItem('isAdmin', (!isAdmin).toString());
  renderizarFormAdmin();
  renderizarProdutos();
}

function renderizarFormAdmin() {
  const isAdmin = localStorage.getItem('isAdmin') === 'true';
  if (!isAdmin) {
    adminFormContainer.classList.add('hidden');
    adminFormContainer.innerHTML = '';
    return;
  }
  adminFormContainer.classList.remove('hidden');
  adminFormContainer.innerHTML = `
    <div style="padding: 32px; background: #f9f9f9; border-radius: 16px; margin: 20px;">
      <h2>${produtoEditando ? 'Editar' : 'Novo'} Produto</h2>
      <input id="admin-nome" placeholder="Nome" value="${novoProduto.nome || ''}">
      <textarea id="admin-descricao" placeholder="Descrição">${novoProduto.descricao || ''}</textarea>
      <input id="admin-preco" type="number" placeholder="Preço" value="${novoProduto.preco || ''}">
      <input id="admin-categoria" placeholder="Categoria" value="${novoProduto.categoria || ''}">
      <input id="admin-midias" placeholder="URL da imagem" value="${(novoProduto.midias || [])[0] || ''}">
      <button onclick="salvarProduto()">Salvar</button>
      ${produtoEditando ? '<button onclick="cancelarEdicao()">Cancelar</button>' : ''}
    </div>
  `;
}

window.salvarProduto = () => {
  novoProduto = {
    id: produtoEditando ? produtoEditando.id : Date.now().toString(),
    nome: document.getElementById('admin-nome').value,
    descricao: document.getElementById('admin-descricao').value,
    preco: parseFloat(document.getElementById('admin-preco').value),
    categoria: document.getElementById('admin-categoria').value,
    midias: [document.getElementById('admin-midias').value],
    tamanhos: [],
    cores: [],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: false
  };

  if (produtoEditando) {
    const index = produtos.findIndex(p => p.id === produtoEditando.id);
    produtos[index] = novoProduto;
  } else {
    produtos.push(novoProduto);
  }

  localStorage.setItem('produtosLoja', JSON.stringify(produtos));
  produtoEditando = null;
  novoProduto = {};
  renderizarFormAdmin();
  renderizarProdutos();
};

window.cancelarEdicao = () => {
  produtoEditando = null;
  novoProduto = {};
  renderizarFormAdmin();
};

export function iniciarEdicao(produto) {
  produtoEditando = produto;
  novoProduto = { ...produto };
  renderizarFormAdmin();
}

export function deletarProduto(id) {
  if (confirm('Deletar produto?')) {
    produtos = produtos.filter(p => p.id !== id);
    localStorage.setItem('produtosLoja', JSON.stringify(produtos));
    renderizarProdutos();
  }
}

export function getProdutos() {
  return produtos;
}