// js/cart-favorites.js

// Carrinho e favoritos armazenados no localStorage
let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
let favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

// Atualiza badges no header
export function atualizarBadges() {
  const cartBadge = document.getElementById('cart-badge');
  const favoritesBadge = document.getElementById('favorites-badge');

  if (cartBadge) {
    cartBadge.textContent = carrinho.reduce((total, item) => total + item.quantidade, 0);
    cartBadge.style.display = carrinho.length > 0 ? 'flex' : 'none';
  }

  if (favoritesBadge) {
    favoritesBadge.textContent = favoritos.length;
    favoritesBadge.style.display = favoritos.length > 0 ? 'flex' : 'none';
  }
}

// Salva no localStorage
function salvarCarrinho() {
  localStorage.setItem('carrinho', JSON.stringify(carrinho));
  atualizarBadges();
}

function salvarFavoritos() {
  localStorage.setItem('favoritos', JSON.stringify(favoritos));
  atualizarBadges();
}

// Adicionar ao carrinho
export function adicionarAoCarrinho(produto, corSelecionada, tamanhoSelecionado) {
  if (!corSelecionada && !produto.corUnica) {
    alert('Selecione uma cor!');
    return;
  }
  if (!tamanhoSelecionado && !produto.tamanhoUnico) {
    alert('Selecione um tamanho!');
    return;
  }

  // Padroniza tamanho único
  if (produto.tamanhoUnico) tamanhoSelecionado = 'Único';
  if (produto.corUnica) corSelecionada = produto.corUnica;

  const existente = carrinho.find(item =>
    item.produto.id === produto.id &&
    item.cor === corSelecionada &&
    item.tamanho === tamanhoSelecionado
  );

  if (existente) {
    existente.quantidade += 1;
  } else {
    carrinho.push({
      produto,
      cor: corSelecionada,
      tamanho: tamanhoSelecionado,
      quantidade: 1
    });
  }

  salvarCarrinho();
  alert('Adicionado ao carrinho!');
}

// Remover item específico do carrinho
export function removerDoCarrinho(index) {
  carrinho.splice(index, 1);
  salvarCarrinho();
  renderizarCarrinho();
}

// Ajustar quantidade
export function ajustarQuantidade(index, delta) {
  carrinho[index].quantidade += delta;
  if (carrinho[index].quantidade <= 0) {
    removerDoCarrinho(index);
  } else {
    salvarCarrinho();
    renderizarCarrinho();
  }
}

// Toggle favorito
export function toggleFavorito(produto) {
  const index = favoritos.findIndex(f => f.id === produto.id);
  if (index === -1) {
    favoritos.push(produto);
  } else {
    favoritos.splice(index, 1);
  }
  salvarFavoritos();
  atualizarBadges();
  // Atualiza ícone no card (se estiver visível)
  const heartBtn = document.querySelector(`[data-produto-id="${produto.id}"] .heart-btn`);
  if (heartBtn) heartBtn.classList.toggle('active', index === -1);
}

// Verifica se é favorito
export function ehFavorito(produtoId) {
  return favoritos.some(f => f.id === produtoId);
}

// Renderiza o sidebar do carrinho
export function renderizarCarrinho() {
  const container = document.getElementById('cart-items');
  const totalEl = document.getElementById('cart-total');
  const checkoutBtn = document.getElementById('checkout-whatsapp');

  if (!container) return;

  if (carrinho.length === 0) {
    container.innerHTML = '<p class="vazio">Seu carrinho está vazio</p>';
    if (totalEl) totalEl.classList.add('hidden');
    if (checkoutBtn) checkoutBtn.classList.add('hidden');
    return;
  }

  container.innerHTML = carrinho.map((item, index) => `
    <div class="item-carrinho">
      <img src="${item.produto.midias[0]}" alt="${item.produto.nome}">
      <div class="info">
        <div class="nome">${item.produto.nome}</div>
        <div class="detalhes">${item.cor} • ${item.tamanho}</div>
        <div class="preco">R$ ${(item.produto.preco * item.quantidade).toFixed(2)}</div>
      </div>
      <div class="quantidade-controls">
        <button onclick="import('./cart-favorites.js').then(m => m.ajustarQuantidade(${index}, -1))">-</button>
        <span>${item.quantidade}</span>
        <button onclick="import('./cart-favorites.js').then(m => m.ajustarQuantidade(${index}, 1))">+</button>
      </div>
      <button class="remover" onclick="import('./cart-favorites.js').then(m => m.removerDoCarrinho(${index}))">
        <i class="fas fa-trash"></i>
      </button>
    </div>
  `).join('');

  const total = carrinho.reduce((acc, item) => acc + (item.produto.preco * item.quantidade), 0);

  if (totalEl) {
    totalEl.innerHTML = `<strong>Total: R$ ${total.toFixed(2)}</strong>`;
    totalEl.classList.remove('hidden');
  }

  if (checkoutBtn) {
    checkoutBtn.classList.remove('hidden');
    checkoutBtn.onclick = () => finalizarCompraWhatsApp();
  }
}

// Renderiza sidebar de favoritos
export function renderizarFavoritos() {
  const container = document.getElementById('favorites-items');

  if (!container) return;

  if (favoritos.length === 0) {
    container.innerHTML = '<p class="vazio">Nenhum item nos favoritos</p>';
    return;
  }

  container.innerHTML = favoritos.map(produto => `
    <div class="item-favorito" onclick="abrirProduto('${produto.id}')">
      <img src="${produto.midias[0]}" alt="${produto.nome}">
      <div>
        <div class="nome">${produto.nome}</div>
        <div class="preco">R$ ${produto.preco.toFixed(2)}</div>
      </div>
    </div>
  `).join('');
}

// Finalizar compra via WhatsApp
function finalizarCompraWhatsApp() {
  if (carrinho.length === 0) {
    alert('Seu carrinho está vazio!');
    return;
  }

  const numeroWhats = "5561982610405"; // Altere para o seu número
  let mensagem = "*Olá! Gostaria de fazer o seguinte pedido:*\n\n";

  carrinho.forEach((item, i) => {
    mensagem += `${i + 1}. ${item.produto.nome}\n`;
    mensagem += `   - Cor: ${item.cor}\n`;
    mensagem += `   - Tamanho: ${item.tamanho}\n`;
    mensagem += `   - Quantidade: ${item.quantidade}\n`;
    mensagem += `   - Preço unitário: R$ ${item.produto.preco.toFixed(2)}\n\n`;
  });

  const total = carrinho.reduce((acc, item) => acc + (item.produto.preco * item.quantidade), 0);
  mensagem += `*Total: R$ ${total.toFixed(2)}*`;

  const url = `https://wa.me/${numeroWhats}?text=${encodeURIComponent(mensagem)}`;
  window.open(url, '_blank');
}

// Inicializa badges ao carregar
atualizarBadges();