// js/main.js

import { produtosIniciais } from './products.js';
import {
  adicionarAoCarrinho,
  toggleFavorito,
  ehFavorito,
  renderizarCarrinho,
  renderizarFavoritos,
  atualizarBadges
} from './cart-favorites.js';

import {
  iniciarEdicao,
  deletarProduto,
  getProdutos
} from './admin.js';

// ================== ESTADO ==================
let produtos = getProdutos()?.length ? getProdutos() : [...produtosIniciais];
let termoPesquisa = '';

// ================== ELEMENTOS DOM ==================
const productsGrid = document.getElementById('products-grid');
const searchInput = document.getElementById('search-input');

const favoritesBtn = document.getElementById('favorites-btn');
const cartBtn = document.getElementById('cart-btn');

const favoritesSidebar = document.getElementById('favorites-sidebar');
const cartSidebar = document.getElementById('cart-sidebar');

const closeFavorites = document.getElementById('close-favorites');
const closeCart = document.getElementById('close-cart');

const productModal = document.getElementById('product-modal');

// ================== DARK MODE AUTOMÁTICO ==================
function detectarDarkMode() {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.body.classList.toggle('dark-mode', prefersDark);
}
detectarDarkMode();

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
  document.body.classList.toggle('dark-mode', e.matches);
});

// ================== RENDERIZA PRODUTOS ==================
export function renderizarProdutos() {
  if (!productsGrid) return;

  const filtrados = produtos.filter(p =>
    p.nome.toLowerCase().includes(termoPesquisa.toLowerCase()) ||
    p.descricao.toLowerCase().includes(termoPesquisa.toLowerCase()) ||
    p.categoria.toLowerCase().includes(termoPesquisa.toLowerCase())
  );

  if (!filtrados.length) {
    productsGrid.innerHTML = `<p class="vazio">Nenhum produto encontrado</p>`;
    return;
  }

  const isAdmin = localStorage.getItem('isAdmin') === 'true';

  productsGrid.innerHTML = filtrados.map(produto => `
    <div class="produto-card">
      
      <div class="card-header-icons">
        <button
          class="heart-btn ${ehFavorito(produto.id) ? 'active' : ''}"
          onclick="import('./cart-favorites.js').then(m => m.toggleFavorito(${JSON.stringify(produto)}))">
          <i class="fas fa-heart"></i>
        </button>
      </div>

      <img
        src="${produto.midias[0] || 'assets/images/placeholder.jpg'}"
        alt="${produto.nome}"
        class="card-imagem"
        onclick="abrirModalProduto('${produto.id}')"
      >

      <div class="card-conteudo">
        <h3>${produto.nome}</h3>

        <p class="card-preco ${produto.esgotado ? 'esgotado' : ''}">
          R$ ${produto.preco.toFixed(2)} ${produto.esgotado ? '(Esgotado)' : ''}
        </p>

        <p class="card-descricao">
          ${produto.descricao.length > 80
            ? produto.descricao.slice(0, 80) + '...'
            : produto.descricao}
        </p>

        <button
          class="btn-adicionar-card"
          onclick="abrirModalProduto('${produto.id}')"
          ${produto.esgotado ? 'disabled' : ''}>
          ${produto.esgotado ? 'Esgotado' : 'Ver detalhes'}
        </button>

        ${isAdmin ? `
          <div class="admin-acoes-card">
            <button onclick="import('./admin.js').then(m => m.iniciarEdicao(${JSON.stringify(produto)}))">
              Editar
            </button>
            <button class="delete-btn"
              onclick="import('./admin.js').then(m => m.deletarProduto('${produto.id}'))">
              Deletar
            </button>
          </div>
        ` : ''}
      </div>
    </div>
  `).join('');
}

// ================== MODAL DO PRODUTO ==================
window.abrirModalProduto = (id) => {
  const produto = produtos.find(p => p.id === id);
  if (!produto) return;

  let corSelecionada = produto.corUnica || produto.cores[0] || '';
  let tamanhoSelecionado = produto.tamanhoUnico ? 'Único' : (produto.tamanhos[0]?.label || '');

  productModal.innerHTML = `
    <div class="modal-conteudo" onclick="event.stopPropagation()">
      <button class="modal-fechar" onclick="fecharModal()">
        <i class="fas fa-times"></i>
      </button>

      <img src="${produto.midias[0]}" class="modal-imagem">

      <h3>${produto.nome}</h3>

      <p class="modal-preco ${produto.esgotado ? 'esgotado' : ''}">
        R$ ${produto.preco.toFixed(2)}
      </p>

      <p>${produto.descricao}</p>

      ${!produto.tamanhoUnico ? `
        <div class="opcao">
          <b>Tamanhos</b>
          <div class="tamanhos-lista">
            ${produto.tamanhos.map(t => `
              <button onclick="tamanhoSelecionado='${t.label}'">${t.label}</button>
            `).join('')}
          </div>
        </div>
      ` : '<p><b>Tamanho:</b> Único</p>'}

      ${produto.cores?.length ? `
        <div class="opcao">
          <b>Cores</b>
          <div class="cores-lista">
            ${produto.cores.map(cor => `
              <span class="bolinha-cor"
                style="background:${getCorHex(cor)}"
                onclick="corSelecionada='${cor}'">
              </span>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <button
        class="btn-adicionar-modal"
        ${produto.esgotado ? 'disabled' : ''}
        onclick="import('./cart-favorites.js')
          .then(m => m.adicionarAoCarrinho(${JSON.stringify(produto)}, corSelecionada, tamanhoSelecionado))">
        ${produto.esgotado ? 'Esgotado' : 'Adicionar ao carrinho'}
      </button>
    </div>
  `;

  productModal.classList.remove('hidden');
};

window.fecharModal = () => {
  productModal.classList.add('hidden');
  productModal.innerHTML = '';
};

// ================== PESQUISA ==================
searchInput?.addEventListener('input', e => {
  termoPesquisa = e.target.value;
  renderizarProdutos();
});

// ================== MENUS LATERAIS ==================
favoritesBtn?.addEventListener('click', () => {
  favoritesSidebar.classList.toggle('aberto');
  cartSidebar.classList.remove('aberto');
  renderizarFavoritos();
});

cartBtn?.addEventListener('click', () => {
  cartSidebar.classList.toggle('aberto');
  favoritesSidebar.classList.remove('aberto');
  renderizarCarrinho();
});

closeFavorites?.addEventListener('click', () => favoritesSidebar.classList.remove('aberto'));
closeCart?.addEventListener('click', () => cartSidebar.classList.remove('aberto'));

// ================== FECHAR AO CLICAR FORA ==================
document.addEventListener('click', e => {
  if (!favoritesSidebar.contains(e.target) && !favoritesBtn.contains(e.target)) {
    favoritesSidebar.classList.remove('aberto');
  }
  if (!cartSidebar.contains(e.target) && !cartBtn.contains(e.target)) {
    cartSidebar.classList.remove('aberto');
  }
  if (!productModal.contains(e.target) && !productModal.classList.contains('hidden')) {
    fecharModal();
  }
});

// ================== UTIL ==================
function getCorHex(cor) {
  const map = {
    Preto: '#000', Branco: '#fff', Azul: '#1E90FF',
    Cinza: '#888', Vermelho: '#FF4136',
    Verde: '#2ECC40', Amarelo: '#FFD700',
    Laranja: '#FFA500', Rosa: '#FFC0CB', Roxo: '#800080'
  };
  return map[cor] || cor;
}

// ================== INIT ==================
renderizarProdutos();
atualizarBadges();
