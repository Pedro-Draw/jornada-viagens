// js/products.js

// Produtos mock iniciais (com imagens reais de alta qualidade - URLs diretas)
export const produtosIniciais = [
  {
    id: "1",
    nome: "Camisa Personalizada Branca",
    descricao: "Camisa 100% algodão premium, confortável e perfeita para personalização com sua logo ou arte exclusiva.",
    preco: 89.90,
    categoria: "Camisas",
    midias: ["https://cdn.mockupnest.com/wp-content/uploads/edd/2024/10/02-Free-Hanging-T-Shirt-Mockup.jpg"],
    tamanhos: [{ label: "P" }, { label: "M" }, { label: "G" }, { label: "GG" }],
    cores: ["Branco", "Preto", "Azul"],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: false
  },
  {
    id: "2",
    nome: "Bermuda Preta Esportiva",
    descricao: "Bermuda tactel leve e respirável, ideal para treinos ou uso casual. Personalize com sua marca.",
    preco: 119.90,
    categoria: "Bermudas",
    midias: ["https://thumbs.dreamstime.com/b/high-quality-d-rendering-pair-black-athletic-shorts-showcasing-both-front-back-views-shorts-feature-393226408.jpg"],
    tamanhos: [{ label: "P" }, { label: "M" }, { label: "G" }],
    cores: ["Preto", "Cinza"],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: false
  },
  {
    id: "3",
    nome: "Boné Preto Snapback",
    descricao: "Boné de alta qualidade com bordado personalizado. Aba reta e ajuste perfeito.",
    preco: 79.90,
    categoria: "Bonés",
    midias: ["https://thumbs.dreamstime.com/z/black-baseball-cap-mockup-front-view-png-file-isolated-cutout-object-shadow-transparent-background-316693476.jpg"],
    tamanhos: [],
    cores: ["Preto"],
    tamanhoUnico: true,
    corUnica: "Preto",
    esgotado: false
  },
  {
    id: "4",
    nome: "Caneca Branca Personalizada",
    descricao: "Caneca de cerâmica 325ml sublimática. Perfeita para estampar sua arte ou frase favorita.",
    preco: 49.90,
    categoria: "Canecas",
    midias: ["https://img.freepik.com/premium-psd/elegant-white-ceramic-mug-daily-use_1158146-37041.jpg?semt=ais_hybrid&w=740&q=80"],
    tamanhos: [],
    cores: ["Branco"],
    tamanhoUnico: true,
    corUnica: "Branco",
    esgotado: false
  },
  {
    id: "5",
    nome: "Casaco Azul com Capuz",
    descricao: "Moletom Canguru premium, quente e estiloso. Personalize com silk ou bordado.",
    preco: 189.90,
    categoria: "Casacos",
    midias: ["https://media.istockphoto.com/id/1282929527/photo/mens-blue-blank-hoodie-template-from-two-sides-natural-shape-on-invisible-mannequin-for-your.jpg?s=612x612&w=0&k=20&c=w_IgS_7ob1VsjShtg7zRIB0bYqiY4qlOAkiKM8ESEjQ="],
    tamanhos: [{ label: "M" }, { label: "G" }, { label: "GG" }],
    cores: ["Azul", "Preto", "Cinza"],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: false
  },
  {
    id: "6",
    nome: "Kimono Jiu-Jitsu Preto A2",
    descricao: "Kimono (gi) de alta qualidade, tecido reforçado, ideal para treino ou competição. Personalize com patches.",
    preco: 449.90,
    categoria: "Kimonos",
    midias: ["https://img.freepik.com/premium-vector/jiujitsu-kimono-mockup-karate-uniform-template-martial-arts-clothing-design-bjj-gi-presentation_769163-214.jpg"],
    tamanhos: [{ label: "A1" }, { label: "A2" }, { label: "A3" }],
    cores: ["Preto", "Branco", "Azul"],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: true
  },
  {
    id: "7",
    nome: "Rash Guard Manga Longa Azul",
    descricao: "Camisa de compressão para treino, proteção UV e secagem rápida. Personalize com sua arte.",
    preco: 149.90,
    categoria: "Rash Guards",
    midias: ["https://i.fbcd.co/products/resized/resized-360-240/1-79dca51058cd6f98a4171613c31e83da6e5b646b8c693d0d03ec2e88f99cc032.jpg"],
    tamanhos: [{ label: "P" }, { label: "M" }, { label: "G" }],
    cores: ["Azul", "Preto"],
    tamanhoUnico: false,
    corUnica: "",
    esgotado: false
  },
  {
    id: "8",
    nome: "Faixa Preta Jiu-Jitsu",
    descricao: "Faixa oficial de graduação preta, tecido premium com etiqueta personalizada.",
    preco: 89.90,
    categoria: "Faixas",
    midias: ["https://img.freepik.com/free-photo/karate-fighter-proudly-holding-black-belt_23-2148446197.jpg?t=st=1765634659~exp=1765638259~hmac=7c6fadc69b2086530eabc5db75c39ce6e93f6604813af82eced69ffa6a10b561"],
    tamanhos: [],
    cores: ["Preto"],
    tamanhoUnico: true,
    corUnica: "Preto",
    esgotado: false
  },
  {
    id: "9",
    nome: "Protetor Bucal Profissional",
    descricao: "Protetor bucal moldável de alta proteção para esportes de contato.",
    preco: 59.90,
    categoria: "Protetores Bucais",
    midias: ["https://m.media-amazon.com/images/I/61oPq29gXHL._AC_UF894,1000_QL80_.jpg"],
    tamanhos: [],
    cores: ["Transparente", "Preto", "Azul"],
    tamanhoUnico: true,
    corUnica: "",
    esgotado: false
  }
];

// Cores disponíveis para o formulário de edição
export const coresDisponiveis = [
  "Preto", "Branco", "Azul", "Cinza", "Vermelho", "Verde", "Amarelo", "Laranja", "Rosa", "Roxo"
];